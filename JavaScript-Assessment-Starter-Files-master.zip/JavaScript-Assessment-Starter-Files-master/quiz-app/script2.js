$.get('http://5d76bf96515d1a0014085cf9.mockapi.io/quiz',function(data,status){
        let response=data;
        let url=window.location.href;
        let infopart=window.location.search.split('&');
        let answers=[];
        for(let i=0;i<infopart.length;i++){
        	let str=infopart[i].split('=');
       		answers.push(str[1]);
        }
        if(answers.length!==response.length){
        	alert('Please answer all the questions');
        }
        else{
        let score=0;
        for(let i=0;i<response.length;i++){
			if(answers[i]==response[i].answer){
				score++;
			}
    	}
    	document.getElementById('modal-wrapper').style.display="block";
    	document.getElementById('result').innerHTML=score;
    }
})