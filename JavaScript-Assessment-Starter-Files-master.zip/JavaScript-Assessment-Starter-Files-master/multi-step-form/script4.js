function ValidateEmail(inputText)
{
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(inputText.value.match(mailformat))
	{
		return true;
	}
	else
	{
		return false;
	}
}

let firstnext=document.getElementById('StepOneNext');
let firstpage=0;
firstnext.addEventListener('click',function(){
	let letters = /[A-Za-z]/;
	let firstname=document.getElementById('first_name'); 
	if(firstname.value.match(letters)){
		firstpage++;
	}
	else{
		document.querySelector('.ErrorText').style.display="block";
	}
	let bool=ValidateEmail(document.getElementById('email').value);
	if(bool===true){
		firstpage++;
	}else{
		document.querySelector('.ErrorText').style.display="block";
	}
	if(firstpage==2){
		document.getElementById('StepOneContainer').style.display="none";
		document.getElementById('StepTwoContainer').style.display="block";
	}
})