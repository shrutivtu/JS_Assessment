var showeyescard=document.getElementById('show-eyes-card');
var showmouth=document.getElementById('show-mouth-card');
var skincard=document.getElementById('select-skin-card');
var eyescard=document.getElementById('select-eyes-card');
var mouthcard=document.getElementById('select-mouth-card');
showeyescard.addEventListener('click',function(){
	skincard.style.display="none";
	eyescard.style.display="block";
});
showmouth.addEventListener('click',function(){
	skincard.style.display="none";
	eyescard.style.display="none";
	mouthcard.style.display="block";
});
document.getElementById('show-skin-card').addEventListener('click',function(){
	skincard.style.display="block";
	eyescard.style.display="none";
	mouthcard.style.display="none";
});
document.getElementById('prev-eyes-card').addEventListener('click',function(){
	skincard.style.display="none";
	eyescard.style.display="block";
	mouthcard.style.display="none";
});
let skin='';
document.getElementById('yellow-skin').addEventListener('click',function(){
	skin=document.getElementById('yellow-skin').src;
	document.getElementById('skin').src=skin;
});
document.getElementById('green-skin').addEventListener('click',function(){
	skin=document.getElementById('green-skin').src;
	document.getElementById('skin').src=skin;
});
document.getElementById('red-skin').addEventListener('click',function(){
	skin=document.getElementById('red-skin').src;
	document.getElementById('skin').src=skin;
});

let eyes='';
document.getElementById('eye-normal').addEventListener('click',function(){
	eyes=document.getElementById('eye-normal').src;
	document.getElementById('eyes').src=eyes;
});
document.getElementById('eye-closed').addEventListener('click',function(){
	eyes=document.getElementById('eye-closed').src;
	document.getElementById('eyes').src=eyes;
});
document.getElementById('eye-long').addEventListener('click',function(){
	eyes=document.getElementById('eye-long').src;
	document.getElementById('eyes').src=eyes;
});
document.getElementById('eye-laughing').addEventListener('click',function(){
	eyes=document.getElementById('eye-laughing').src;
	document.getElementById('eyes').src=eyes;
});
document.getElementById('eye-rolling').addEventListener('click',function(){
	eyes=document.getElementById('eye-rolling').src;
	document.getElementById('eyes').src=eyes;
});
document.getElementById('eye-winking').addEventListener('click',function(){
	eyes=document.getElementById('eye-winking').src;
	document.getElementById('eyes').src=eyes;
});

let mouth='';

document.getElementById('mouth-open').addEventListener('click',function(){
	mouth=document.getElementById('mouth-open').src;
	document.getElementById('mouth').src=mouth;
});
document.getElementById('mouth-smiling').addEventListener('click',function(){
	mouth=document.getElementById('mouth-smiling').src;
	document.getElementById('mouth').src=mouth;
});
document.getElementById('mouth-straight').addEventListener('click',function(){
	mouth=document.getElementById('mouth-straight').src;
	document.getElementById('mouth').src=mouth;
});
document.getElementById('mouth-sad').addEventListener('click',function(){
	mouth=document.getElementById('mouth-open').src;
	document.getElementById('mouth').src=mouth;
});
document.getElementById('mouth-teeth').addEventListener('click',function(){
	mouth=document.getElementById('mouth-teeth').src;
	document.getElementById('mouth').src=mouth;
});