function anotherfunction(id){
        let url='http://5d76bf96515d1a0014085cf9.mockapi.io/video/'+id;
        let src='https://player.vimeo.com/video/';
        $.get(url,function(data,status){
            let response=data;
            src=src+response.vimeoId;
            document.getElementById('video-player').src=src;
            document.getElementById('views-count').innerHTML=response.views;
            document.getElementById('video-title').innerHTML=response.title;
            document.getElementById('video-description').innerHTML
            =response.description;
        })
}



$.get('https://5d76bf96515d1a0014085cf9.mockapi.io/playlist',function(data,status){
        let response=data;
        /*var jsonstring=JSON.stringify(response);*/
        console.log(response);
        for(let i=0;i<response.length;i++){
            document.querySelector('.thumbnail').src=response[i].thumbnail;
            document.querySelector('.video-card-title').src=response[i].title; 
        }
        let id=0;
        document.querySelector('#card1').addEventListener('click',function(){
                id=1;
                anotherfunction(id);
        });
        document.querySelector('#card2').addEventListener('click',function(){
                id=2;
                anotherfunction(id);
        });
        document.querySelector('#card3').addEventListener('click',function(){
                id=3;
                anotherfunction(id);
        });
        document.querySelector('#card4').addEventListener('click',function(){
                id=4;
                anotherfunction(id);
        });
        document.querySelector('#card5').addEventListener('click',function(){
                id=5;
                anotherfunction(id);
        });
        document.querySelector('#card6').addEventListener('click',function(){
                id=6;
                anotherfunction(id);
        });
})